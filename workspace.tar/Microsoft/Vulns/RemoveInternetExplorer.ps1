dism /online /Disable-Feature /FeatureName:Internet-Explorer-Optional-amd64
