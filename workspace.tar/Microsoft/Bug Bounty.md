

I think it is the time to get bounty and HOF from Microsoft:-

Bounty range from $500 up to $20,000

Join me please.

I got the subdomains here on google drive or try to use aquatone or sniper for more:-

https://drive.google.com/file/d/1QkyD4wimPHfYPwA4S6sdCBlO81KXpPRZ/view?usp=sharing

IN SCOPE VULNERABILITIES

Cross site scripting (XSS) Cross site request forgery (CSRF) Cross-tenant data tampering or access Insecure direct object references Insecure deserialization Injection vulnerabilities Server-side code execution Significant security misconfiguration (when not caused by user) Using component with known vulnerabilities Unauthorized cross-tenant data tampering or access

IN-SCOPE DOMAINS AND ENDPOINTS

www.office.com protection.office.com onedrive.live.com onedrive.com portal.azure.com manage.windowsazure.com blog.azure.com portal.office.com outlook.office365.com outlook.office.com outlook.com outlook.com sharepoint.com (excluding user-generated content) lync.com officeapps.live.com www.yammer.com sway.com sway.office.com teams.microsoft.com join.microsoft.com admin.microsoft.com graph.microsoft.com

The PROGRAM DESCRIPTION and SCOPE:-

https://www.microsoft.com/en-us/msrc/bounty-microsoft-cloud

For Office 365 services, you can set up your test account:-

https://portal.office.com/Signup/Signup.aspx…

For Azure services, you can start a free trial to use as your test account:-

https://azure.microsoft.com/en-us/free/

For Microsoft Account, you can set up your test account:-

http://signup.live.com/

Send your findings to:-

bounty@microsoft.com

Best of luck for all.
