# Offensive Security

## Purple Team

[![OpenSSF Best Practices](https://www.bestpractices.dev/projects/8496/badge)](https://www.bestpractices.dev/projects/8496)
