```ShellSesion
yay -Syuuq --noconfirm
```

```ShellSesion
paru -Syuq --noconfirm
```

```ShellSesion
sudo pacman -Syuu --needed --disable-download-timeout --noprogressbar --overwrite --noconfirm
```
