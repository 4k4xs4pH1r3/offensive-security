# Ubunter

An automated tool to turn your ubuntu machine into a hacking lab

------------------------------------------------------------------------

# How to Install

Open the terminal and type following commands

* `apt update`

* `apt install git`

* `git clone https://github.com/UncleJ1ck/Ubunter`

* `cd Ubunter`

* `chmod +x ./ubunter.sh`

* `sudo ./ubunter.sh`

------------------------------------------------------------------------

Once the installation is complete, restart your machine!

------------------------------------------------------------------------

<p align="center">
<img src="https://raw.githubusercontent.com/UncleJ1ck/Ubunter/main/img/ubunter.png">

------------------------------------------------------------------------
  
# Note 
  
Tested on Ubuntu 20.04
