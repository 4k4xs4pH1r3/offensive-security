```
conda config --add channels conda-forge && conda create -n x python=3.13 && conda activate x
```
