https://docs.microsoft.com/en-us/visualstudio/liveshare/reference/linux#install-linux-prerequisites
