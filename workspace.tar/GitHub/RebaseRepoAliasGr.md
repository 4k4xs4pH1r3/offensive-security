```
echo "alias gr='git stash; git checkout master; git pull; git checkout -; git rebase master; git stash pop'" >> ~/.zshrc && source ~/.zshrc
```
